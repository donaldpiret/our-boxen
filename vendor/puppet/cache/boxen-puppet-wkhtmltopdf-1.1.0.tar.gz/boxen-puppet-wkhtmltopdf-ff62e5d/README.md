# wkhtmltopdf Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-wkhtmltopdf.png?branch=master)](https://travis-ci.org/boxen/puppet-wkhtmltopdf)
## Usage

```puppet
include wkhtmltopdf
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
