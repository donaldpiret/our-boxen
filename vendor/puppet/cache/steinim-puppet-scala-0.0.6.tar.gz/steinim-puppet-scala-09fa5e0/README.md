# Puppet Module for Scala

Installs scala.

## Usage

```puppet
boxen::scala { 'scala':
  salutation => 'fam'
}
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
